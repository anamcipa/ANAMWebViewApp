# ANAM CIPAA WebView App

Android WebView wrapper untuk panel:

https://anam176.my.id/

## Fitur
- Buka panel langsung di WebView.
- JavaScript, localStorage, session/cookie aktif.
- Support WebSocket realtime dari panel.
- Tombol back Android kembali ke halaman sebelumnya.
- File chooser dasar aktif.
- Link luar domain dibuka lewat browser/aplikasi eksternal.
- HTTPS only.

## Cara build APK
1. Install Android Studio.
2. Open folder `ANAMWebViewApp`.
3. Tunggu Gradle sync selesai.
4. Build > Generate Signed Bundle / APK.
5. Pilih APK.

## Ganti URL
Edit file:

app/src/main/java/id/my/anam176/webview/MainActivity.java

Ubah:

private static final String HOME_URL = "https://anam176.my.id/";

## Ganti nama app
Edit:

app/src/main/res/values/strings.xml
