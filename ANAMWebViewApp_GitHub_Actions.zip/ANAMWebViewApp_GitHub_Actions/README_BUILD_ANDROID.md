# Build APK dari Android lewat GitHub Actions

1. Buka github.com dari Chrome Android.
2. Buat repository baru.
3. Upload semua isi folder ini ke repository.
4. Buka tab Actions.
5. Pilih workflow "Build Android APK".
6. Klik "Run workflow".
7. Setelah selesai, buka hasil run > Artifacts > download "ANAM-CIPAA-debug-apk".
8. Extract ZIP artifact, lalu install ANAM-CIPAA-debug.apk.

URL app ada di:
app/src/main/java/id/my/anam176/webview/MainActivity.java

HOME_URL = "https://anam176.my.id/"
