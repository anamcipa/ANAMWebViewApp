# ANAM CIPAA WebView App - URL Switch

Android WebView wrapper untuk panel:

https://anam176.my.id/

## Fitur
- Buka panel langsung di WebView.
- JavaScript, localStorage, session/cookie aktif.
- Support WebSocket realtime dari panel.
- Tombol back Android kembali ke halaman sebelumnya.
- File chooser dasar aktif.
- Link luar domain dibuka lewat browser/aplikasi eksternal.
- HTTPS only.
- Tombol kecil `URL` di kanan atas untuk ganti tujuan WebView tanpa rebuild lagi.

## Tombol URL
Klik tombol `URL`, lalu isi salah satu:

- `https://anam176.my.id/dashboard`
- `https://anam176.my.id/admin`
- `https://anam176.my.id/docs`
- `/admin`

URL terakhir akan tersimpan. Tahan tombol `URL` untuk reset ke dashboard utama.

## Cara build APK
1. Upload ZIP project ke GitHub.
2. Jalankan GitHub Actions.
3. Download artifact APK.
