# ANAM CIPAA Browser Mode APK

Fitur:
- Address/search bar manual seperti browser.
- Bisa buka /admin, /docs, URL lengkap, atau pencarian Google.
- Tombol refresh.
- Toggle Mobile/Desktop.
- Desktop mode sudah memaksa viewport 1280px, bukan hanya mengganti user-agent.

Upload ZIP ini ke repo GitHub lalu jalankan Actions build APK.
