# ANAM CIPAA WebView App - Browser Mode

Android WebView wrapper untuk panel ANAM.

Default URL:

https://anam176.my.id/

## Fitur
- Address/search bar manual di bagian atas seperti browser.
- Bisa ketik URL penuh, domain, path seperti `/admin`, atau kata pencarian.
- Tombol `Go` untuk buka alamat.
- Tombol `↻` untuk refresh. Tahan lama tombol ini untuk balik ke dashboard.
- Tombol `Mobile/Desktop` untuk ganti mode tampilan WebView.
- URL terakhir tersimpan.
- JavaScript, localStorage, session/cookie aktif.
- Support WebSocket realtime dari panel.
- Tombol back Android kembali ke halaman sebelumnya.
- File chooser dasar aktif.

## Contoh input address bar
- `/admin`
- `/docs`
- `anam176.my.id/admin`
- `https://anam176.my.id/admin`
- `cek website`

## Cara build APK
Upload ZIP ini ke repo GitHub yang sama, lalu jalankan workflow build APK.
