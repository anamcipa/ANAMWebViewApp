# Build APK dari Android lewat GitHub Actions

Cara paling gampang dari HP:

1. Upload ZIP `ANAMWebViewApp_GitHub_Actions_URL_Switch.zip` ke repo GitHub kamu.
2. Kalau workflow kamu sudah pakai unzip project, klik tab Actions.
3. Run workflow.
4. Download artifact `ANAM-CIPAA-url-switch-debug-apk`.
5. Extract artifact, install APK.

Tombol URL ada di kanan atas aplikasi.

Contoh isi URL untuk admin:

/admin

atau:

https://anam176.my.id/admin
