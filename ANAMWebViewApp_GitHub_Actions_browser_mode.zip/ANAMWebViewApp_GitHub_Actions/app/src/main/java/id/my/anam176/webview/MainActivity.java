package id.my.anam176.webview;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLEncoder;

public class MainActivity extends Activity {
    private static final String DEFAULT_URL = "https://anam176.my.id/";
    private static final String BASE_HOST = "anam176.my.id";
    private static final String PREFS_NAME = "anam_webview_prefs";
    private static final String PREF_HOME_URL = "home_url";
    private static final String PREF_DESKTOP_MODE = "desktop_mode";
    private static final int FILE_CHOOSER_REQUEST = 1001;

    private WebView webView;
    private ProgressBar progressBar;
    private FrameLayout webContainer;
    private LinearLayout rootLayout;
    private LinearLayout browserBar;
    private EditText addressInput;
    private TextView goButton;
    private TextView modeButton;
    private TextView refreshButton;
    private TextView offlineView;
    private ValueCallback<Uri[]> filePathCallback;
    private SharedPreferences prefs;
    private String currentHomeUrl = DEFAULT_URL;
    private String mobileUserAgent = "";
    private boolean desktopMode = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        currentHomeUrl = normalizeUrl(prefs.getString(PREF_HOME_URL, DEFAULT_URL));
        desktopMode = prefs.getBoolean(PREF_DESKTOP_MODE, false);

        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(0xFF020617);

        browserBar = new LinearLayout(this);
        browserBar.setOrientation(LinearLayout.HORIZONTAL);
        browserBar.setGravity(Gravity.CENTER_VERTICAL);
        browserBar.setPadding(dp(8), dp(8), dp(8), dp(6));
        browserBar.setBackgroundColor(0xFF020617);

        addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setTextColor(0xFFE2E8F0);
        addressInput.setHintTextColor(0xFF64748B);
        addressInput.setTextSize(13);
        addressInput.setSelectAllOnFocus(true);
        addressInput.setHint("Ketik URL /admin /docs atau pencarian...");
        addressInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        addressInput.setPadding(dp(12), 0, dp(12), 0);
        addressInput.setBackground(makeRoundDrawable(0xFF0F172A, 0x4422D3EE, dp(16)));
        addressInput.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP;
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                openFromAddressBar();
                return true;
            }
            return false;
        });

        goButton = makeBarButton("Go");
        goButton.setOnClickListener(v -> openFromAddressBar());

        refreshButton = makeBarButton("↻");
        refreshButton.setTextSize(16);
        refreshButton.setOnClickListener(v -> {
            if (webView != null) webView.reload();
        });
        refreshButton.setOnLongClickListener(v -> {
            loadUrl(DEFAULT_URL, true);
            Toast.makeText(this, "Kembali ke dashboard", Toast.LENGTH_SHORT).show();
            return true;
        });

        modeButton = makeBarButton(desktopMode ? "Desktop" : "Mobile");
        modeButton.setOnClickListener(v -> toggleDesktopMode());

        LinearLayout.LayoutParams addressParams = new LinearLayout.LayoutParams(0, dp(42), 1);
        browserBar.addView(addressInput, addressParams);
        addBarButton(goButton, 46);
        addBarButton(refreshButton, 42);
        addBarButton(modeButton, 78);

        webContainer = new FrameLayout(this);
        webView = new WebView(this);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);

        offlineView = new TextView(this);
        offlineView.setText("Koneksi internet tidak tersedia.\nTap untuk coba lagi.");
        offlineView.setTextColor(0xFFE2E8F0);
        offlineView.setTextSize(15);
        offlineView.setGravity(Gravity.CENTER);
        offlineView.setBackgroundColor(0xFF020617);
        offlineView.setVisibility(View.GONE);
        offlineView.setOnClickListener(v -> loadHome());

        webContainer.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        webContainer.addView(progressBar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(3),
                Gravity.TOP
        ));
        webContainer.addView(offlineView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        rootLayout.addView(browserBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        rootLayout.addView(webContainer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1
        ));
        setContentView(rootLayout);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        mobileUserAgent = settings.getUserAgentString();
        applyViewMode(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }
        CookieManager.getInstance().setAcceptCookie(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                offlineView.setVisibility(View.GONE);
                progressBar.setVisibility(View.VISIBLE);
                updateAddress(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                CookieManager.getInstance().flush();
                progressBar.setVisibility(View.GONE);
                updateAddress(url);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                if (failingUrl != null && isAllowedHost(failingUrl)) {
                    showOffline();
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    intent = fileChooserParams.createIntent();
                } else {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    MainActivity.this.filePathCallback = null;
                    Toast.makeText(MainActivity.this, "File picker tidak tersedia", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e) {
                Toast.makeText(this, "Tidak bisa membuka download", Toast.LENGTH_SHORT).show();
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
            String restored = webView.getUrl();
            updateAddress(restored != null ? restored : currentHomeUrl);
        } else {
            loadHome();
        }
    }

    private TextView makeBarButton(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setGravity(Gravity.CENTER);
        view.setTextColor(0xFFECFEFF);
        view.setTextSize(12);
        view.setTypeface(null, Typeface.BOLD);
        view.setBackground(makeRoundDrawable(0xFF0F172A, 0x4422D3EE, dp(15)));
        view.setPadding(dp(5), 0, dp(5), 0);
        return view;
    }

    private void addBarButton(View view, int widthDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(widthDp), dp(42));
        params.setMargins(dp(6), 0, 0, 0);
        browserBar.addView(view, params);
    }

    private void openFromAddressBar() {
        hideKeyboard();
        String target = smartInputToUrl(addressInput.getText().toString());
        loadUrl(target, true);
    }

    private void toggleDesktopMode() {
        desktopMode = !desktopMode;
        prefs.edit().putBoolean(PREF_DESKTOP_MODE, desktopMode).apply();
        applyViewMode(true);
        Toast.makeText(this, desktopMode ? "Mode desktop aktif" : "Mode mobile aktif", Toast.LENGTH_SHORT).show();
    }

    private void applyViewMode(boolean reload) {
        WebSettings settings = webView.getSettings();
        if (desktopMode) {
            settings.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36 ANAMWebView/Desktop");
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);
            settings.setTextZoom(90);
            webView.setInitialScale(85);
            modeButton.setText("Desktop");
        } else {
            settings.setUserAgentString((mobileUserAgent == null || mobileUserAgent.isEmpty() ? settings.getUserAgentString() : mobileUserAgent) + " ANAMWebView/Mobile");
            settings.setUseWideViewPort(false);
            settings.setLoadWithOverviewMode(false);
            settings.setTextZoom(100);
            webView.setInitialScale(0);
            modeButton.setText("Mobile");
        }
        if (reload && webView.getUrl() != null) {
            webView.reload();
        }
    }

    private boolean handleUrl(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();

        if (scheme.equals("http") || scheme.equals("https")) {
            updateAddress(url);
            return false;
        }
        if (scheme.equals("tel") || scheme.equals("mailto") || scheme.equals("whatsapp") || scheme.equals("tg")) {
            openExternal(url);
            return true;
        }
        return false;
    }

    private boolean isAllowedHost(String url) {
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
            String currentHost = Uri.parse(currentHomeUrl).getHost();
            currentHost = currentHost == null ? "" : currentHost.toLowerCase();
            return host.equals(BASE_HOST) || (!currentHost.isEmpty() && host.equals(currentHost));
        } catch (Exception e) {
            return false;
        }
    }

    private void openExternal(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) {
            Toast.makeText(this, "Link tidak bisa dibuka", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadHome() {
        loadUrl(currentHomeUrl, false);
    }

    private void loadUrl(String rawUrl, boolean saveAsHome) {
        String target = normalizeUrl(rawUrl);
        if (!isHttpUrl(target)) {
            target = DEFAULT_URL;
        }
        if (!isOnline()) {
            currentHomeUrl = target;
            if (saveAsHome) saveHomeUrl(target);
            updateAddress(target);
            showOffline();
            return;
        }
        currentHomeUrl = target;
        if (saveAsHome) saveHomeUrl(target);
        offlineView.setVisibility(View.GONE);
        updateAddress(target);
        webView.loadUrl(target);
    }

    private void saveHomeUrl(String url) {
        prefs.edit().putString(PREF_HOME_URL, normalizeUrl(url)).apply();
    }

    private String smartInputToUrl(String input) {
        String value = input == null ? "" : input.trim();
        if (value.isEmpty()) return DEFAULT_URL;
        if (value.startsWith("/")) return "https://" + BASE_HOST + value;
        if (value.startsWith("http://") || value.startsWith("https://")) return value;
        if (!value.contains(" ") && value.contains(".")) return "https://" + value;
        try {
            return "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8");
        } catch (Exception e) {
            return DEFAULT_URL;
        }
    }

    private String normalizeUrl(String rawUrl) {
        String value = rawUrl == null ? "" : rawUrl.trim();
        if (value.isEmpty()) return DEFAULT_URL;
        if (value.startsWith("/")) {
            value = "https://" + BASE_HOST + value;
        }
        if (!value.startsWith("http://") && !value.startsWith("https://")) {
            value = smartInputToUrl(value);
        }
        return value;
    }

    private boolean isHttpUrl(String url) {
        try {
            String scheme = Uri.parse(url).getScheme();
            return "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme);
        } catch (Exception e) {
            return false;
        }
    }

    private void updateAddress(String url) {
        if (url == null || addressInput == null) return;
        if (!addressInput.hasFocus()) {
            addressInput.setText(url);
            addressInput.setSelection(addressInput.getText().length());
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(addressInput.getWindowToken(), 0);
            addressInput.clearFocus();
        } catch (Exception ignored) {}
    }

    private void showOffline() {
        progressBar.setVisibility(View.GONE);
        offlineView.setVisibility(View.VISIBLE);
    }

    private boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo info = cm != null ? cm.getActiveNetworkInfo() : null;
            return info != null && info.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    private android.graphics.drawable.Drawable makeRoundDrawable(int fillColor, int strokeColor, int radiusPx) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(radiusPx);
        drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) {
                    results = new Uri[]{uri};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }
}
